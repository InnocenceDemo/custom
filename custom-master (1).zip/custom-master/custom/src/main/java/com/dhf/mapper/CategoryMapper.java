package com.dhf.mapper;

import com.dhf.domain.Category;

import java.util.List;
import java.util.Map;

public interface CategoryMapper {

    List<Map> selectAllCategorys();
}
