package com.dhf.service;

import com.dhf.domain.Category;

import java.util.List;
import java.util.Map;

public interface CategoryService {

    List<Map> selectAllCategorys();
}
