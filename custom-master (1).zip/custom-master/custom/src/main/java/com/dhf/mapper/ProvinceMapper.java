package com.dhf.mapper;

import java.util.List;
import java.util.Map;

public interface ProvinceMapper {

    List<Map<String, Object>> selectAllProvinces();
}
